/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.sql.*;

/**
 *
 * @author SHASHANK
 */
public class tables {
    public static void main(String[]args){
        try
        {
            String adminDetails="insert into javaproject(Userid,Username,FirstName,LastName,Password,DOB,UserAge,UserHobbies);"
        }
    }
    
}
