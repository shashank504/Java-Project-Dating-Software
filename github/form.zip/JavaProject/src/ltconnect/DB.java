package ltconnect;
/*
import com.sun.jdi.connect.spi.Connection;
import javax.swing.*;
import javax.swing.table.DefaultTableColumnModel;
import com.mysql.jdbc.ResultSetMetaData;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Vector;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SHASHANK
 */
/*
public class DB {
    Connection conn=null;
    java.sql.PreparedStatement pst;
    public static Connection dbconnect()
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql:/localhost:3306 /letstalk","root","12345");
            return conn;
        }
    catch (Expectation e2)
    {
        System.out.println(e2);
        return null;
    }
    }
    
    
    
}*/

//mustafiz



import java.sql.*;


public class DB {
    
     static Connection conn;
  
     
  public static Connection dbconnect(){
    
    try{
        //load the driver
        Class.forName("com.mysql.jdbc.Driver");
        
        //Creat a connection
        String url="jdbc:mysql://localhost:3306/customer";
        String user="root";
        String password="Ravishashank504";
        conn=DriverManager.getConnection(url,user,password);
       
        
        
        
        
    }
    catch(Exception e){
        e.printStackTrace();
       
    }
     return conn;
    }
}